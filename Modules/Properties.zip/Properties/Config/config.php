<?php

return [
    'name' => 'Properties'
];
