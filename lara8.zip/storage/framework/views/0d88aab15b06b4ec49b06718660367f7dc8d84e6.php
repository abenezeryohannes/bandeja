<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: <?php echo config('plan.name'); ?>

    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plan::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/dkibru/KInventory/CODE/mala/ChurchDotEt/Modules/Plan/Resources/views/index.blade.php ENDPATH**/ ?>