<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: <?php echo config('user.name'); ?>

    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/dkibru/KInventory/CODE/abenezer/lara8/Modules/User/Resources/views/index.blade.php ENDPATH**/ ?>