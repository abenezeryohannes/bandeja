<!DOCTYPE html>
<html  style="height: auto; min-height: 100%;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e($meta['title']); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo e(url('static_assets/bootstrap.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('static_assets/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(url('static_assets/Ionicons/css/ionicons.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('static_assets/adminlte/AdminLTE.min.css')); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(url('static_assets/adminlte/skins/_all-skins.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <script src="<?php echo e(mix('js/manifest.js')); ?>" defer></script>
    <script src="<?php echo e(mix('js/vendor.js')); ?>" defer></script>

    <script src="<?php echo e(mix('js/components.js').'?v='.env('FRONTEND_VERSION')); ?>" defer></script>
    <script src="<?php echo e(mix('js/app.js').'?v='.env('FRONTEND_VERSION')); ?>" defer></script>
</head>
<body  class="hold-transition skin-green layout-top-nav fixed" style="height: auto; min-height: 100%;">
<div class="wrapper" style="height: auto; min-height: 100%;" id="app" v-cloak>
    <!-- <div class="hold-transition skin-blue sidebar-mini" >   -->
    <router-view 
    ></router-view>
</div>

<style>
    [v-cloak] > * {
        display: none;
    }
    [v-cloak]::before {
        content: url(<?php echo e(url('/img/loading.gif')); ?>);
        text-align: center;
        display: block;
        height:100%;
        vertical-align: middle;
        position: relative;
        background-color: white;
    }
</style>

</body>
</html>
<?php /**PATH /media/dkibru/KInventory/CODE/mala/ChurchDotEt/frontend/blade/app.blade.php ENDPATH**/ ?>