# ToDo

vue event driven ... event subscriber



sudo apt-get install php7.4-xml php7.4-gd php7.4-intl php7.4-xsl php7.4-sqlite3 php7.4-zip php7.4-mbstring php7.4-mysqli

sudo apt install -y php7.2 php7.2-cli php7.2-common php7.2-fpm