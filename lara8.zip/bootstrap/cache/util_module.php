<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Util\\Providers\\UtilServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Util\\Providers\\UtilServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);