<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Church\\Providers\\ChurchServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Church\\Providers\\ChurchServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);