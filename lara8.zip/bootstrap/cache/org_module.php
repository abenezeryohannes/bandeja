<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Org\\Providers\\OrgServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Org\\Providers\\OrgServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);