<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\D\\Providers\\DServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\D\\Providers\\DServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);