<?php

namespace Modules\Church\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ChurchInfo extends \App\Models\LocalizableModel
{
    use HasFactory;

    protected $fillable = [
    	'code', 'value_en', 'value_am', 'type'
    ];

    // protected $appendLocalizedAttributes = false;
    // protected $hideLocaleSpecificAttributes = false;

    protected $localizable = [
        'value',
    ];
    
    protected static function newFactory()
    {
        return \Modules\Church\Database\factories\ChurchInfoFactory::new();
    }
}
