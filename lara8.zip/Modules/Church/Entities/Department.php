<?php

namespace Modules\Church\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Department extends \App\Models\LocalizableModel
{
    use HasFactory;

    protected $fillable = [
    	'name_en','name_am', 
    ];

    protected $localizable = [
        'name',
    ];

    
    protected static function newFactory()
    {
        return \Modules\Church\Database\factories\DepartmentFactory::new();
    }
}
