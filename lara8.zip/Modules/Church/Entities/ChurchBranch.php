<?php

namespace Modules\Church\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ChurchBranch extends \App\Models\LocalizableModel
{
    use HasFactory;

    protected $table = "church_branches";

    protected $fillable = [
    	'name_en','name_am', 'city', 'is_main_office'
    ];

    protected $localizable = [
        'name',
    ];
    
    protected static function newFactory()
    {
        return \Modules\Church\Database\factories\BranchFactory::new();
    }
}
