<?php

return [
    'name' => 'Installation'
];
