# steps

php artisan install:info
