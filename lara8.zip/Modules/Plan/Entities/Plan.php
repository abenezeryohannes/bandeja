<?php

namespace Modules\Plan\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Plan extends Model
{
    use HasFactory;

    protected $fillable = ["department_id","title","content"];

    protected $casts = [
    	"content" => "array"
    ];

    public function department()
    {
    	return $this->belongsTo(\Modules\Church\Entities\Department::class);
    }
    
    protected static function newFactory()
    {
        return \Modules\Plan\Database\factories\PlanFactory::new();
    }
}
