<?php

return [
    'name' => 'Plan'
];
