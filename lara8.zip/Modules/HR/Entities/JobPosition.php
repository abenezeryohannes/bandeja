<?php

namespace Modules\HR\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class JobPosition extends Model
{
    use HasFactory;

    protected $fillable = [ 'title', 'roles' ];
    
    protected static function newFactory()
    {
        return \Modules\HR\Database\factories\JobPositionFactory::new();
    }

    protected $casts  = [
    	'roles' => 'array'
    ];
}
