<?php

namespace Modules\HR\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class EmploymentHistory extends Model
{
    use HasFactory;

    protected $fillable = [
    	"user_id", "birth_year", "birth_month", "birth_date", "educational_background",
    	"region", "zone", "woreda", "kebele", 
    	"start_date", "end_date",
    	"job_position_id", "employement_type", "church_branch_id",
    	"bank_name", "bank_ac_no", "salary"
    ];

    protected $appends = ["age"];


    public function getAgeAttribute()
    {
        if(!$this->birth_year)
            return null;
        return now()->format("Y") - $this->birth_year;
    }


    public function user()
    {
    	return $this->belongsTo(\Modules\User\Entities\User::class);
    }

    public function job_position()
    {
    	return $this->belongsTo(\Modules\HR\Entities\JobPosition::class);
    }

    public function church_branch()
    {
    	return $this->belongsTo(\Modules\Church\Entities\ChurchBranch::class);
    }
    
    protected static function newFactory()
    {
        return \Modules\HR\Database\factories\EmploymentHistoryFactory::new();
    }

}
