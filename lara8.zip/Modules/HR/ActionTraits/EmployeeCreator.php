<?php

namespace Modules\HR\ActionTraits;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\HR\Entities\JobPosition;
use Modules\User\Entities\User;
use Modules\HR\Entities\EmploymentHistory;

use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;


trait EmployeeCreator
{

    protected function create_employee($args)
    {
    	// return $args;

    	$faker = \Faker\Factory::create();
        $domain = "church.et";

        do{
            $email_generated = $faker->lexify('?????@'.$domain);
        }while(User::where('email_generated', $email_generated)->first());
        $password_generated = $faker->lexify('??????');
        $password = Hash::make($password_generated);

        $args['locale'] = "en";

        $u = User::create([
            'name' => $args['name'], 'sex' => $args['sex'], 'locale'  => $args['locale'],
            'email'  => $args['email'] ?? null, 'email_generated' => $email_generated,
            'password' => $password, 'password_generated' => $password_generated, 
            'role'  => 'employee',
            'church_branch_id'=> $args["branch"]
        ]);

        $age = $args['age'] ?? null;
        $birth_year = null;
        if ($age) {
        	$birth_year = now()->format("Y") - $age;
        }

    	$r = EmploymentHistory::create([

	    	"user_id" => $u->id, "church_branch_id" => $args["branch"], "job_position_id" => $args["position"], 
	    	"birth_year" => $birth_year, "birth_month" => null, "birth_date" => null, 
	    	"educational_background" => $args["educational_background"] ?? null,
	    	"region" => $args["region"] ?? null, "zone" => $args["zone"] ?? null, "woreda" => $args["woreda"] ?? null, "kebele" => $args["kebele"] ?? null, 
	    	"start_date" => null, "end_date" => null,
	    	"employement_type" => $args['employement_type'], 
	    	"bank_name" => $args['bank_account_name'] ?? null, "bank_ac_no" => null, "salary" => $args['salary'] ?? null
    	]);
    	return $r;

    }


}
