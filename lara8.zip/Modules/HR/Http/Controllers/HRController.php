<?php

namespace Modules\HR\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class HRController extends Controller
{

    public function __invoke()
    {
        return response()->json([
            'strings' => [
                'hr' => __("hr"),
                'employee' => __("hr.employee"),
            ]
        ]);
    }
}
