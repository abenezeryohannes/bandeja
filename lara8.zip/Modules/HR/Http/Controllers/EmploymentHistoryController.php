<?php

namespace Modules\HR\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\HR\Entities\JobPosition;

use Modules\Util\Traits\Tableable;
use Modules\HR\Entities\EmploymentHistory;
class EmploymentHistoryController extends Controller
{

    use \Modules\HR\ActionTraits\EmployeeCreator,
        Tableable;

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function toTable()
    {
        return EmploymentHistory::all()->map(function($e){
            return [
                "id" => $e->id,
                "name" => $e->user->name,
                "roles_short" => [ $e->job_position->title ],
            ];
        });
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return response()->json([
            'data' => [
                'positions' => JobPosition::all()->map(function($x){
                    return ['code' => $x->id, 'label' => $x->title];
                }),
                'regions' => \Modules\Util\Federalism\Region::get(),
                

                'educational_background' => \Modules\Util\Enum\EducationalBackground::getAll(),
                'banks' => \Modules\Util\Enum\Bank::getAll(),
                'branches' => \Modules\Church\Entities\ChurchBranch::all()->map(function($x){
                    return [
                        'code' => $x->id,
                        'label'  => $x->name
                    ];
                }),
                'employement_types' => \Modules\Util\Enum\EmployementType::getAll()
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required',
            'sex' => 'required',
            'branch' => 'required',
            'position' => 'required',
            'email' => 'unique:users',
            'image' => 'file'
        ]);

        $t = $this->create_employee($request->all());
        return response()->json([
            $t
        ]);
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $e = EmploymentHistory::find($id);
        $e['name'] = $e->user->name;
        $e['password_generated'] = $e->user['password_generated'];
        $e['sex'] = $e->user['sex'];
        $e['email'] = $e->user['email'];
        $e['the_email'] = $e->user['email_generated'];

        $e['the_password'] = $e->user['password_generated'] ;
        $e['phone_number'] = $e->user['password_generated'] ;
        $e['position'] = $e->job_position['title'] ;
        $e['the_branch'] = $e->church_branch['name'] ;

        // 'name', 'sex', 'avatar', 'locale',
        // 'email', 'email_generated', 'phone_number',
        // 'password', 'password_generated', 
        // 'role', 'elevated_permissions',

        // 'church_branch_id'
        return response()->json([
            'user' => $e,
            "strings" => [

            ] 
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('hr::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $m = EmploymentHistory::find($id);
        switch ($request->updatable) {
            case 'the_branch':
                $request->updatable  = "branch_id";
                break;
            case 'email':
                $request['email'] = $request->updatable_value;
                $request->validate([
                    'email' => 'email|unique:users',
                ]);
                break;
            case 'age':
                return response()->json(['message' => 'Code Can not be modified'], 401);
                break;
            default:
//                $m[$request->updatable] = $request->updatable_value;
                break;
        }
        $user_attributes = ['email','name'];
        $key = $request->updatable;
        $in_user_table = array_search($key, $user_attributes);
        if ($in_user_table !== false) {
            $u = $m->user;
            $u->$key = $request->updatable_value;
            // return ["dd"];
            $u->save();
        }
        // $in_employee_table = array_search($request->updatable, $array);
        // return [$in_user_table, $key, $request];

//        eval(" = $request->updatable_value;");
//        dd($request->updatable);
        // $m->$key = $request->updatable_value;
        // $m->save();
//        $m = $this->updateTable($request,$m);
        return response()->json([
            'data' => EmploymentHistory::find($id)->user
        ]);
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
