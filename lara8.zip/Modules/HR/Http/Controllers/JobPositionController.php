<?php

namespace Modules\HR\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

use Modules\HR\Entities\JobPosition;

use Modules\Util\Traits\Tableable;
class JobPositionController extends Controller
{
    use Tableable;

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function toTable()
    {
        return JobPosition::all()->map(function($j){
            $j['roles'] =collect( $j['roles'])->map(function($r) {
                return __('roles.'. strtolower($r) );
            });
            return $j;
        });
        // return collect(["ss"]);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $roles = \Modules\User\Services\RoleHasPermissions::roles();
        return response()->json([
            'data' => [
                'roles' => collect($roles)->map(function($r){
                    return ['label'=> __('roles.'. strtolower($r) ), 'code'=> $r];
                }) 
                // [
                //     ,
                //     ['label'=> 'Finance Officer', 'code'=> 'FINANCE'],
                //     ['label'=> 'Inventory Manger', 'code'=> 'INVENTORY'],
                // ]
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'roles' => 'required',
        ]);
        $roles = explode("|",$request->roles);
        $roles = collect($roles)->push("EMPLOYEE");
        $roles = $roles->unique();
        $j = JobPosition::create([
            'title' => $request->title, 
            'roles' => $roles
        ]);
        return response()->json([
            $j
        ]);
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('hr::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('hr::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $r = JobPosition::find($id);
        $r->delete();

        return response()->json([
            $r
        ]);
    }
}
