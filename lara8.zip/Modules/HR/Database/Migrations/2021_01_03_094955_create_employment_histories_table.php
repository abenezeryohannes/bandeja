<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmploymentHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employment_histories', function (Blueprint $table) {
            $table->id('id');

            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')
                ->references('id')
                ->on('users');

            $table->year('birth_year')->nullable();
            $table->year('birth_month')->nullable();
            $table->year('birth_date')->nullable();
            
            $table->string('educational_background')->nullable();
            
            $table->string('region')->nullable();
            $table->string('zone')->nullable();
            $table->string('woreda')->nullable();
            $table->string('kebele')->nullable();

            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->unsignedBigInteger('job_position_id');
            $table->foreign('job_position_id')
                ->references('id')
                ->on('job_positions');
            $table->string('employement_type')->nullable();
            $table->unsignedBigInteger('church_branch_id');
            $table->foreign('church_branch_id')
                ->references('id')
                ->on('church_branches');



            $table->string('bank_name')->nullable();
            $table->string('bank_ac_no')->nullable();
            $table->float('salary',8,2)->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employment_histories');
    }
}
