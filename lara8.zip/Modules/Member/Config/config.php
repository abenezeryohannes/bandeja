<?php

return [
    'name' => 'Member'
];
