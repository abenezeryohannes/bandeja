<?php

return [
    'name' => 'Website'
];
