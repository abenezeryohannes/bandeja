<?php

return [

    'unauthenticated' => 'You are not an authenticated user',

];
