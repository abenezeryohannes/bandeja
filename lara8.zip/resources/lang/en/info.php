<?php

return [

    'developer_name' => 'Milfan Tech Solutions',
    'copyright_text' => 'Copyright &copy; :year',
    'all_rights' => 'All rights reserved.',


];
