<?php

return [

    'admin' => 'Admin',
    'finance' => 'Financial Officer.',
    'hr' => 'Human Resource Officer',
    'employee' => 'Employee',
    'department_leader' => 'Department Leader',

];
