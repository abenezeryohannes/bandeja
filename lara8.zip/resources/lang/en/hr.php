<?php

return [

    'employee' => 'Employee',

];
