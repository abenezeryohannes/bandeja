<?php

return [
    'dashboard' => 'Dashboard',
    'properties' => 'Properties',
    'expenses' => 'Expenses',
    'incomes' => 'Incomes',
    'shares' => 'Shares',
    'banking' => 'Banking',
    'reports' => 'Reports',
    'settings' => 'Settings',

    'transactions' => 'Transactions',
    'accounts' => 'Accounts',
    'interests' => 'Interests',

    'dividend_income' => 'Dividend Income',
    'shareholders' => 'Shareholders',
    'rental' => 'Rental',
    'accounts' => 'Accounts',

    'invoices' => 'Invoices',
    'revenues' => 'Revenues',
    'tenants' => 'Tenants',

    'share_ledgers' => 'Share Ledgers',
    'dividend_incomes' => 'Dividend Incomes',
    'share_holders' => 'Share Holders',

    'bills' => 'Bills',
    'payment' => 'Payment',
    'vendors' => 'Vendors',

    'properties' => 'Properties',
    'categories' => 'Categories',
    'sites' => 'Sites',
    'blocks' => 'Blocks',

];





