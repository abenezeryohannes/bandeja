<?php

return [
	'visionary' => 'ባለራእይ',
    'admin' => 'አድሚን',
    'finance' => 'የፋይናንስ አስተዳደር',
    'hr' => 'የሰው ሀይል አስተዳደር',
    'employee' => 'ሰራተኛ',

];
