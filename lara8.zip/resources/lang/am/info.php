<?php

return [

    'developer_name' => 'Mala Tech Solutions',
    'copyright_text' => 'Copyright &copy; 2013',
    'all_rights' => 'መብቱ በህግ የተጠበቀ ነው',


];
