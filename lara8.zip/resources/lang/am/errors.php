<?php

return [

    'unauthenticated' => 'Erso authenticated adelum',

];
