<?php

return [

    'employee' => 'ሰራተኛ',

];
