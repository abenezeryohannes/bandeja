<?php

return [

    'church_members' => 'ምእመናን',
    'hr' => 'የሰው ሀይል',
    'events' => 'ክስተቶች',
    'finance' => 'ፋይናንስ',
    'plan' => 'እቅድ',
    'inventory' => 'ኢንቨንቶሪ',
];
